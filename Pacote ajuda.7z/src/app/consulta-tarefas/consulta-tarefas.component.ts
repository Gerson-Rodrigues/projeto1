import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consulta-tarefas',
  templateUrl: './consulta-tarefas.component.html',
  styleUrls: ['./consulta-tarefas.component.css']
})
export class ConsultaTarefasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

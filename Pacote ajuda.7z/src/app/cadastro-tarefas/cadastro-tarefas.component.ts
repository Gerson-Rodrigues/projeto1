import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastro-tarefas',
  templateUrl: './cadastro-tarefas.component.html',
  styleUrls: ['./cadastro-tarefas.component.css']
})
export class CadastroTarefasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

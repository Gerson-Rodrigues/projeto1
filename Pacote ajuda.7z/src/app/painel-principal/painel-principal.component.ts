import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-painel-principal',
  templateUrl: './painel-principal.component.html',
  styleUrls: ['./painel-principal.component.css']
})
export class PainelPrincipalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
